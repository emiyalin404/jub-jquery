$(document).ready(function() { 
 $('div.poem-stanza').addClass('highlight'); 
 console.log('hello'); 
 console.log(52); 
 console.log($('div.poem-stanza')); 
});